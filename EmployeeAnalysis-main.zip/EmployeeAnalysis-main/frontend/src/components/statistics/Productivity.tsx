import React from "react";

function Productivity() {
  return (
    <>
      <div>Productivity</div>
    </>
  );
}

export default Productivity;
