export type Employee = {
    employee_id: BigInteger;
    employee_firstname: string;
    employee_surname: string;
    employee_email: string;
}